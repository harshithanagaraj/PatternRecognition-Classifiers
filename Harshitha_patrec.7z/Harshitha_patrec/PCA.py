import pandas as pd
import random
import numpy as np
import sys
import matplotlib
from sklearn import cluster as Kcluster, metrics as SK_Metrics
from sklearn.decomposition import PCA
from sklearn.preprocessing import Normalizer, StandardScaler
from matplotlib import pyplot

df=pd.read_csv("Indian Liver Patient Dataset (ILPD).csv")
#df=pd.read_csv("DataSet_final.csv")
df1=df.ix[:,0:9]

def find_pca(data_frame):
    #Step 1: Finding the number of PCAs required

    #Standardize features by removing the mean and scaling to unit variance
    #fit_transform determines which tokens it will count, and how they correspond to entries in the count vector.
    std= StandardScaler().fit_transform(data_frame)
    #finding mean of each column
    #getting the covariance mattrix 
    cov_mat = np.cov(std.T)
    #Compute the eigenvalues and right eigenvectors of a square array
    eig_vals, eig_vecs = np.linalg.eig(cov_mat)
    #print eig_vals
    #comp will contain the number PCA required
    comp=0
    for vr in eig_vals:
        #checking if the eigen value is greater than 1
        if(vr>1):
            comp+=1
    #Step 2: perform PCA, wchih will return 'comp' number of PCA components
    pca=PCA( n_components=comp)
    #retriving the requried dataset columns from the original dataset
    variable=pd.DataFrame(pca.fit_transform(data_frame))
    return variable

#function to create a new CSV file
def createFile(data, file_name):
    data.to_csv(file_name,index=False, header=False,sep=',')

#screeplot(df1)
df2=find_pca(df1)
df2["class"]=df["class"]
createFile(df2,"after_pca.csv")

