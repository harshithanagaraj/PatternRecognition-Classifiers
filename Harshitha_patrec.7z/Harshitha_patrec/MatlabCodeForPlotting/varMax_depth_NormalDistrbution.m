%varying max_depth for normal distribution dataset
x = [3, 4, 5, 6, 7, 10, 15, 20, 50];
time = [19.305, 26.756, 29.488, 31.351, 36.217, 48.337, 39.165, 43.261, 42.369];
acc = [85.00, 85.60, 86.00, 86.50, 86.40, 86.20, 86.20, 86.20, 86.20];

subplot(2,1,1);
plot(x,time);
title('Max depth vs time');
xlabel('Max depth');
ylabel('time');
subplot(2,1,2);
plot(x,acc);
title('Max depth vs Time');
xlabel('Max Depth');
ylabel('Time');