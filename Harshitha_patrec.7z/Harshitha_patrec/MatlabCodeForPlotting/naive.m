x = [0.65, 0.66, 0.67, 0.68, 0.69, 0.7, 0.71, 0.72, 0.73, 0.74, 0.75];
acc = [80.51, 81.28, 81.88, 82.76, 81.63, 81.32, 83.15, 82.31, 82.14, 82.29, 81.15];
time = [0.369, 0.335, 0.32, 0.387, 0.374, 0.362, 0.357, 0.347, 0.366, 0.356, 0.36];


subplot(2,1,1);
plot(x,time);
title('Split Ratio vs time');
xlabel('Split Ratio');
ylabel('time');
ylim([0,1]);
subplot(2,1,2);
plot(x,acc);
title('Split Ratio vs Accuracy');
xlabel('Split Ratio');
ylabel('Accuracy');
ylim([0,100]);