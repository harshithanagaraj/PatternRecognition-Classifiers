%varying max_depth for Indian Liver Patient Dataset
x = [1, 2, 3, 4, 5, 7, 8, 9, 10, 15, 20];
time = [2.036, 3.388, 3.428, 3.466, 3.457, 3.428, 3.481, 3.622, 3.534, 3.53, 3.535];

plot(x,time);
title('Max depth vs time');
xlabel('Max depth');
ylabel('time');