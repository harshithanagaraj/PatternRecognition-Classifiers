%varying min_size for normal distribution dataset
x = [1, 10, 20, 50, 100, 200, 300, 500, 600, 800];
time = [39.152, 34.856, 35.671, 38.261, 35.115, 36.217, 32.699, 20.132, 10.620, 9.644];
acc = [86.40, 86.40, 86.40, 86.40, 86.40, 86.40, 85.80, 84.70, 81.90, 81.80];

subplot(2,1,1);
plot(x,time);
title('Min size vs time');
xlabel('Min Size');
ylabel('time');
subplot(2,1,2);
plot(x,acc);
title('Min size vs Time');
xlabel('Min size');
ylabel('Time');