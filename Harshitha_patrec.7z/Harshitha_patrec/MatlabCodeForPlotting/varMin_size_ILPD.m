%varying min_size for Indian Liver Patient Dataset
x = [2, 3, 5, 10, 200, 300, 400, 500, 600, 700];
time = [3.476, 3.544, 3.602, 3.827, 3.654, 3.636, 3.691, 2.172, 2.03, 2.111];

plot(x,time);
title('Min size vs time');
xlabel('Min size');
ylabel('time');