x = [-5:0.1:5];
%%Class1
%norm1 = normpdf(x,0.7694607619, 1.350108049); 
%norm2 = normpdf(x,0.2647911337, 1);
%norm3 = normpdf(x,0.3658133632, 0.9728232472);
%norm4 = normpdf(x,0.9732026116, 0.7158199648); 
%norm5 = normpdf(x,0.5186719045, 0.9434328512); 
%norm6 = normpdf(x,-0.5307152636, 1.2342018831); 
%norm7 = normpdf(x,0.2811702318, 1.176691975);
%norm8 = normpdf(x,-0.1180385559, 1.0698213466); 
%norm9 = normpdf(x,0.7568641566, 0.857751699);
%norm10 = normpdf(x,0.226172692, 1.2806068086);

%%Class2 
norm1 = normpdf(x,-0.7216643073, 1.3); 
norm2 = normpdf(x,0.9953940835, 1.4222862173); 
norm3 = normpdf(x,-0.6584453907, 1.2130726455); 
norm4 = normpdf(x,1.4615508197, 1.5); 
norm5 = normpdf(x,0.8941655307, 1.4542560223); 
norm6 = normpdf(x,-0.9624629714, 1.525115904); 
norm7 = normpdf(x,0.7409973671, 1.1129787445); 
norm8 = normpdf(x,-1.4390497305, 1.1015848176); 
norm9 = normpdf(x,0.9871072606, 0.9605704489); 
norm10 = normpdf(x,1.57746025, 0.800744242); 

plot(x, norm1, x, norm2, x, norm3, x, norm4, x, norm5, x, norm6, x, norm7, x, norm8, x, norm9, x, norm10);